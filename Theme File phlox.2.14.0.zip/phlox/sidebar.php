<?php
/* The sidebar widget area is triggered if any of the areas have widgets. */
locate_template('sidebar-primary.php', true, false );
locate_template('sidebar-secondary.php', true, false );
